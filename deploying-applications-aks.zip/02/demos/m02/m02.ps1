# Create an ACR
# The name must have at least 6 characters, only letters and numbers, must be globally unique
# SKUs: Basic, Standard, Premium
$ACR_NAME=""
az acr create -n $ACR_NAME -g $RG --sku Basic

# Let's list all our ACRs
az acr list -o table

# Our repository is empty
az acr repository list -n $ACR_NAME -o table

# Now, we'll import the hello-world image from the docker repository
az acr import -n $ACR_NAME --source docker.io/library/hello-world:latest -t hello-world-backup:1.0.0

# We now have one repository
az acr repository list -n $ACR_NAME -o table

# With one image
az acr repository show -n $ACR_NAME --repository hello-world-backup -o table

# And one tag
az acr repository show-tags -n $ACR_NAME --repository hello-world-backup -o table

# Let's import this again, with a new tag
az acr import -n $ACR_NAME --source docker.io/library/hello-world:latest -t hello-world-backup:1.1.0

# And also another image
az acr import  -n $ACR_NAME --source docker.io/library/nginx:latest --image nginx:v1

# And check the repositories again
az acr repository list -n $ACR_NAME -o table

# As well as the tags in the hello-world-backup
az acr repository show-tags -n $ACR_NAME --repository hello-world-backup -o table 

# Clone a sample project from GitHub
git clone https://github.com/Azure-Samples/acr-build-helloworld-node

# It's a simple hello world webserver
code .\acr-build-helloworld-node\server.js

# We can now directly build this
az acr build --registry $ACR_NAME --image helloacrtasks:v1 acr-build-helloworld-node

# Clean up
Remove-Item acr-build-helloworld-node -Recurse -Force

# We now have three repositories
az acr repository list -n $ACR_NAME -o table

# Now we want to deploy one of these images 
# Let's get our ACR's Login Server
az acr show -n $ACR_NAME -o table
$loginServer=(az acr show -n $ACR_NAME --query loginServer)

# New Namespace
kubectl create namespace acr
kubectl config set-context --current --namespace acr

# Let's create a deployment
kubectl create deployment nginx --image=$loginServer/nginx:v1

# But did our deployment work?
kubectl get deployment

# Let's check out the pod
kubectl get pods

# Let's take a closer look...
kubectl describe pod (kubectl get pods -o=jsonpath='{.items[0].metadata.name}')

# Let's delete the deployment again...
kubectl delete deployment nginx

# We need to attach the ACR to our AKS Cluster (could also do that on create)
az aks update -n $AKSCluster -g $RG --attach-acr $ACR_NAME

# Now, let's try this again
kubectl create deployment nginx --image=$loginServer/nginx:v1

# How is our deployment looking now?
kubectl get deployment,pods

kubectl describe pod (kubectl get pods -o=jsonpath='{.items[0].metadata.name}') | grep Image:

# Of course, we can also use a yaml manifest for this
code private-nginx.yaml

# Let's also deploy this
kubectl.exe apply -f .\private-nginx.yaml

kubectl get deployment

# Cleanup
kubectl delete namespace acr
Clear-Host