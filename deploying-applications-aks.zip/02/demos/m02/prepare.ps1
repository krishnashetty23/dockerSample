# Check for prerequisites 
# Install-Module -Name powershell-yaml 
Import-Module powershell-yaml

# https://git-scm.com/book/en/v2/Getting-Started-Installing-Git
git version

# https://helm.sh/docs/intro/install/
helm version

# Set variables to be used in the scripts in other demos
$Region="eastus"
$RG="AKSRG"
$Sub=""
$AKSCluster="AKSCluster"

# Get your tenant's name
Start-Process "https://portal.azure.com/#blade/Microsoft_AAD_IAM/ActiveDirectoryMenuBlade/Overview"
$TenantName=""

az login
az account set -s $Sub

# Create an RG and AKS cluster first
az group create -l $Region -n $RG
az aks create -g $RG -n $AKSCluster

# Get the credentials and check the connectivity
az aks get-credentials -g $RG -n $AKSCluster --overwrite-existing
kubectl get nodes

Clear-Host