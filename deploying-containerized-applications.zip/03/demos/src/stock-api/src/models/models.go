package models

type Product struct {
	ID       int64  `json:"id"`
	Stock    int64  `json:"stock"`
}
