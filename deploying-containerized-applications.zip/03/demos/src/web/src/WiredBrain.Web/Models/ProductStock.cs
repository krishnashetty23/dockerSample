﻿namespace WiredBrain.Web.Models
{
    public class ProductStock
    {
        public long Id { get; set; }

        public int Stock { get; set; }
    }
}
