
# create resource group
$rg = 'ps-docker-run'
$region = 'eastus'
az group create --name $rg --location $region